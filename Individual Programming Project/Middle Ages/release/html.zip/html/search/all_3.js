var searchData=
[
  ['endgame',['endGame',['../engine_8h.html#ac959cf8cbd90d8dc203659e8a8871664',1,'engine.c']]],
  ['endturn',['endTurn',['../engine_8h.html#adff6ca550bc33a22dc1e6966c7a5d608',1,'engine.c']]],
  ['engine_2eh',['engine.h',['../engine_8h.html',1,'']]]
];
