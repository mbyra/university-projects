var searchData=
[
  ['dokumentacja_20zadania_20Średniowiecze',['Dokumentacja Zadania Średniowiecze',['../index.html',1,'']]]
];
